package com.FoodPostman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodProjectPostmanApplicationTests {

	@Test
	void contextLoads() {
	}

}
