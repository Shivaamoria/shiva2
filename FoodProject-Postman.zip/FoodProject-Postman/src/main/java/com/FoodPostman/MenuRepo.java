package com.FoodPostman;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;



public interface MenuRepo extends JpaRepository<Menu,Integer> {
	List<Menu> findByCategory(String category);
	List<Menu> findByPrice(double price);
}
