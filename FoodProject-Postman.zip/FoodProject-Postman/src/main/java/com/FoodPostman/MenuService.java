package com.FoodPostman;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MenuService {
	@Autowired
	MenuRepo menurepo;
	@Autowired
	CartRepo cartrepo;

	public Menu getItemById(int id) {
		return menurepo.findById(id).get();
	}

	public List<Menu> getAllItems() {
		List<Menu> items = new ArrayList<Menu>();
		menurepo.findAll().forEach(item -> items.add(item));
		return items;
	}

	public void save(Menu menu) {
		menurepo.save(menu);
	}

	public void deleteItemById(int id) {
		menurepo.deleteById(id);
	}

	public List<Menu> findAllItem(String category) {
		List<Menu> items = new ArrayList<Menu>();
		menurepo.findByCategory(category).forEach(item -> items.add(item));
		return items;
	}

	public List<Menu> findAllItems(String item) {
		List<Menu> items = new ArrayList<Menu>();
		menurepo.findByItem(item).forEach(itemi -> items.add(itemi));
		return items;
	}

	public List<Cart> getAllIt() {
		List<Cart> citems = new ArrayList<Cart>();
		cartrepo.findAll().forEach(itm -> citems.add(itm));
		return citems;
	}

	public List<Cart> findAllIt(String name) {
		List<Cart> names = new ArrayList<Cart>();
		cartrepo.findByName(name).forEach(citm -> names.add(citm));
		return names;
	}

	public void save(Cart cart) {
		cartrepo.save(cart);
	}
}
