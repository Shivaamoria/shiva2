package com.FoodPostman;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class MenuService {
	@Autowired
	MenuRepo menurepo;
	 public Menu getItemById(int id) {
	      return menurepo.findById(id).get();
	   }
	   public List<Menu> getAllItems(){
	      List<Menu> employees = new ArrayList<Menu>();
	      menurepo.findAll().forEach(employee -> employees.add(employee));
	      return employees;
	   }
//	   public void save(Menu menu) {
//	      menu.save(menu);
//	   }
	   public void deleteItemById(int id) {
	      menurepo.deleteById(id);
	   }
	   public List<Menu> findAllItem(String category){
		      List<Menu> items = new ArrayList<Menu>();
		      menurepo.findByCategory(category).forEach(item -> items.add(item));
		      return items;
		   }
	   public List<Menu> findAllItem(double price){
		      List<Menu> items = new ArrayList<Menu>();
		      menurepo.findByPrice(price).forEach(item -> items.add(item));
		      return items;
		   }

}
