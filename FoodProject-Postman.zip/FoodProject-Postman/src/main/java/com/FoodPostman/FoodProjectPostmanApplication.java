package com.FoodPostman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodProjectPostmanApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodProjectPostmanApplication.class, args);
	}

}
